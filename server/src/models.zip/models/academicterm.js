import Sequelize from "sequelize";
import sequelize from "../config/database.js";

const AcademicTerm = sequelize.define('semester', {
    id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
    year: { type: Sequelize.INTEGER, allowNull: false, unique: true},
    term: { type: Sequelize.ENUM("TERM 1", "TERM 2", "TERM 3"), allowNull: false, unique: true}
    
});

export default AcademicTerm;