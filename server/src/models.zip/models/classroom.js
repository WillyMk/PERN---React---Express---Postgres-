import Sequelize from "sequelize";
import sequelize from "../config/database.js";

const ClassRoom = sequelize.define("classroom", {
    id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
    name: { type: Sequelize.STRING, allowNull: false},
    level: { type: Sequelize.INTEGER, allowNull: false},
})

export default ClassRoom;