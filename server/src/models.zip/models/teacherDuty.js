import { Sequelize } from "sequelize";
import sequelize from "../config/database.js";
import Teacher from "./teacher.js";

const TeacherDuty = sequelize.define("teacherDuty", {
    id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
    day: { type: Sequelize.ENUM("Monday", "Tuesday", "Wednesday", "Thursday", "Friday"), allowNull: false }
});

TeacherDuty.belongsTo(Teacher, { foreignKey: "teacherId"})

export default TeacherDuty;