import { Sequelize } from "sequelize";
import sequelize from "../config/database.js";

const Subject = sequelize.define("subject", {
    id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
    name: { type: Sequelize.STRING, allowNull: false},
});

export default Subject;