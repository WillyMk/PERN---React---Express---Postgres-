import sequelize from "../config/database.js";
import { Sequelize } from "sequelize";
import User from "./user.js";

const Teacher = sequelize.define("teacher", {
    id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
    employeeNumber: { type: Sequelize.toString, unique: true} 
})

Teacher.belongsTo(User, { foreignKey: "userId" });

export default Teacher;