import { Sequelize } from "sequelize";
import sequelize from "../config/database.js";
import Subject from "./subject.js";
import Student from "./student.js";
import AcademicTerm from "./academicterm.js";

const Marks = sequelize.define("marks", {
    id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
    examName: { type: Sequelize.STRING, allowNull: false},
    score: { type: Sequelize.FLOAT, allowNull: false},
})

Marks.belongsTo(Student, { foreignKey: "studentId" });
Marks.belongsTo(Subject, { foreignKey: "subjectId" });
Marks.belongsTo(AcademicTerm, { foreignKey: "termId" });

export default Marks;