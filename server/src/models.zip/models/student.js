import sequelize from "../config/database.js";
import { Sequelize } from "sequelize";
import User from "./user.js";
import Dormitory from "./dormitory.js";
import ClassRoom from "./classroom.js";

const Student = sequelize.define("student", {
    id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
    admissionNumber: { type: Sequelize.STRING, unique: true, allowNull: false},
    isBoarding: { type: Sequelize.BOOLEAN, defaultValue: false },
    graduates: { type: Sequelize.BOOLEAN, defaultValue: false }
})

Student.belongsTo(User, { foreignKey: "userId" });
Student.belongsTo(Dormitory, { foreignKey: "dormitoryId" });
Student.belongsTo(ClassRoom, { foreignKey: "classroomId" });

export default Student;